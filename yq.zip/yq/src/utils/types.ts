export interface TruthType{
    page?: number
}